create
    definer = root@localhost procedure client_factura_cel_mai_mic_numar_de_zile_din_an(IN an int)
SELECT C.nume, F.nr_zile
	FROM Client C JOIN Factura F ON (C.id_c = F.id_c)
	WHERE EXTRACT(YEAR from data) = an and F.nr_zile <= ALL(
		SELECT nr_zile 
		FROM Factura
		WHERE EXTRACT(YEAR from data) = an );

