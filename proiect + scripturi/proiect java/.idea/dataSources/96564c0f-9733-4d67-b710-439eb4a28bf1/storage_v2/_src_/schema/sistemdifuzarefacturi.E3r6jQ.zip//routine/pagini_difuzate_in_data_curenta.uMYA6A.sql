create
    definer = root@localhost procedure pagini_difuzate_in_data_curenta()
SELECT L.denumire, SUM(F.nr_pagini) AS total_nr_pagini
	FROM Localitate L JOIN Difuzare D ON (D.id_l = L.id_l)
	JOIN Factura F ON (D.id_f = F.id_f)
	WHERE F.data = CURDATE()
	GROUP BY L.denumire;

