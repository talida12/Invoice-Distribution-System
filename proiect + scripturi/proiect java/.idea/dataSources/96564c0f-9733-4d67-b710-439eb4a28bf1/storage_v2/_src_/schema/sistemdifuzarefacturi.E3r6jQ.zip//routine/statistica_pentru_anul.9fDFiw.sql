create
    definer = root@localhost procedure statistica_pentru_anul(IN an int)
SELECT MIN(valoare_totala) AS valoare_minima, AVG(valoare_totala) AS valoare_medie, MAX(valoare_totala) AS valoare_maxima
	FROM Factura
	WHERE EXTRACT(YEAR from data) = an;

