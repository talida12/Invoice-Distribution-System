create
    definer = root@localhost procedure difuzari_in_luna_valoare_sub(IN dataMin date, IN dataMax date, IN valoareMax int)
SELECT DISTINCT L.denumire /*, D.datai, D.datas, F.valoare*/
	FROM Localitate L JOIN Difuzare D ON (L.id_l = D.id_l)
	/*JOIN Factura F ON (D.id_f = F.id_f)*/
	WHERE  D.id_l IN (
		SELECT id_l FROM Difuzare 
		WHERE (datai >= dataMin AND datai <= dataMax)
		OR (datas >= dataMin AND datas <= dataMax))
	AND D.id_f IN (
		SELECT id_f FROM Factura
		WHERE valoare_totala < valoareMax);

