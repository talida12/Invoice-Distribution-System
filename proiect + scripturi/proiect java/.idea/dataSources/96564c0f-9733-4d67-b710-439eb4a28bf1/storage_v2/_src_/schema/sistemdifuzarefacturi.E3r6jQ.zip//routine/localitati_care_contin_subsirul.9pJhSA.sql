create
    definer = root@localhost procedure localitati_care_contin_subsirul(IN subsir varchar(25))
SELECT denumire AS localitate
	FROM Localitate
	WHERE LOWER(denumire) LIKE CONCAT('%',subsir,'%')
	ORDER BY denumire;

