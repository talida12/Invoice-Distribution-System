create
    definer = root@localhost procedure perechi_de_localitati()
SELECT DISTINCT D1.id_l AS localitate1, D2.id_l AS localitate2
	FROM Difuzare D1 JOIN Difuzare D2
	ON D1.id_f = D2.id_f
	WHERE D1.datai = D2.datai AND D1.datas = D2.datas AND D1.id_l < D2.id_l;

