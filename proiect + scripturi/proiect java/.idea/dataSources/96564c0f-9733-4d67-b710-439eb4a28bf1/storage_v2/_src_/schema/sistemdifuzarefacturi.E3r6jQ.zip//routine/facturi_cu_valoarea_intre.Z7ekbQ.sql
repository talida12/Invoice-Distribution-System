create
    definer = root@localhost procedure facturi_cu_valoarea_intre(IN minim double, IN maxim double)
SELECT * FROM Factura
	WHERE (valoare > minim AND valoare < maxim)
	ORDER BY data DESC, valoare;

