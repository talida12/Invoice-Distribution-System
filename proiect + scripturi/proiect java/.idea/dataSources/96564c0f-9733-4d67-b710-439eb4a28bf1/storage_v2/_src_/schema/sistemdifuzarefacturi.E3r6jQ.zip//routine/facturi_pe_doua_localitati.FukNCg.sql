create
    definer = root@localhost procedure facturi_pe_doua_localitati(IN localitate1 varchar(25), IN localitate2 varchar(25))
SELECT DISTINCT C.nume
	FROM Client C JOIN Factura F ON (C.id_c = F.id_c ) 
	JOIN Difuzare D ON (D.id_f = F.id_f) 
	JOIN Localitate L ON (L.id_l = D.id_l)
    JOIN Factura F2 ON (C.id_c = F2.id_c)
    JOIN Difuzare D2 ON (F2.id_f = D2.id_f)
    JOIN Localitate L2 ON (L2.id_l = D2.id_l)
	WHERE(L.denumire = localitate1 AND L2.denumire = localitate2 );

